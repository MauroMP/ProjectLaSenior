package Exception;

public class ServiciosException extends Exception{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ServiciosException (String mensaje) {
		super(mensaje);
	}

}
