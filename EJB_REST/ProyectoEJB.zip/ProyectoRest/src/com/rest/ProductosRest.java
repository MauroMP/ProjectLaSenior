package com.rest;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.EJB;
import javax.enterprise.context.RequestScoped;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.google.gson.Gson;

import Exception.ServiciosException;
import Servicio.ProductoBeanRemote;
import dominio.Almacenamiento;
import dominio.Familia;
import dominio.Movimiento;
import dominio.Producto;


@RequestScoped
@Path("prod")

@Consumes({ MediaType.APPLICATION_JSON})
@Produces({ MediaType.APPLICATION_JSON})

public class ProductosRest {

	
	@EJB
	private ProductoBeanRemote prodbean;
	
	@GET
	@Path("prods")
	@Produces({ MediaType.APPLICATION_JSON})
	public List<Producto> getProductos () throws ServiciosException {
		List<Producto> listprod = new ArrayList<>();
	listprod = prodbean.obtenerProductos();
	return listprod;
	}
	
	@GET
	@Path("familia")
	@Produces({ MediaType.APPLICATION_JSON})
	public List<Familia> getFamilias () throws ServiciosException {
		List<Familia> listfami = new ArrayList<>();
	listfami = prodbean.obtenerFamilias();
	return listfami;
	}
	
	@GET
	@Path("obtnom")
	@Produces({ MediaType.APPLICATION_JSON})
	public List<String> getObtNom () throws ServiciosException {
		List<Producto> listprod = new ArrayList<>();
		List<String> listprodn = new ArrayList<>();
	listprod = prodbean.obtenerProductos();
	for(Producto i:listprod ) {
		String n = i.getProdNombre();
		listprodn.add(n);
	}
	return listprodn;
	}
	
	@GET
	@Path("stockprod/{prod}")
	@Produces({ MediaType.APPLICATION_JSON})
	public List<String> getStockprod (@PathParam ("prod") String prod) throws ServiciosException {
		List<Producto> listprod = new ArrayList<>();
		List<String> listprodn = new ArrayList<>();
	listprod = prodbean.obtenerProductos();
	for(Producto i:listprod ) {
		if(i.getProdNombre().equals(prod)) {
			Double d = i.getProdStktotal();
			String n="";
			
			n = d.toString();
			
			listprodn.add(n);
		}
		
	}
	return listprodn;
	}
	
	@GET
	@Path("costoprod/{prod}")
	@Produces({ MediaType.APPLICATION_JSON})
	public List<String> getcostoprod (@PathParam ("prod") String prod) throws ServiciosException {
		List<Producto> listprod = new ArrayList<>();
		List<String> listprodn = new ArrayList<>();
	listprod = prodbean.obtenerProductos();
	for(Producto i:listprod ) {
		if(i.getProdNombre().equals(prod)) {
			Double d = i.getProdPrecio();
			String n="";
			
			n = d.toString();
			
			listprodn.add(n);
		}
		
	}
	return listprodn;
	}
	
	@GET
	@Path("familianom")
	@Produces({ MediaType.APPLICATION_JSON})
	public List<String> getFamiliasnom () throws ServiciosException {
		List<Familia> listfami = new ArrayList<>();
		List<String>listnom = new ArrayList<>();
	listfami = prodbean.obtenerFamilias();
	for (Familia i:listfami) {
		listnom.add(i.getFamiNombre());
	}
	return listnom;
	}
	
	@GET
	 @Path("/{nombre}")
	 @Produces({ MediaType.APPLICATION_JSON})
	 public Producto getProducto (@PathParam ("nombre") String nombre) throws ServiciosException {
			List<Producto> prodl = new ArrayList<>();
		prodl = prodbean.obtenerProductos();
		Producto prod = new Producto();
		for(Producto p : prodl) {
			if (p.getProdNombre().equals(nombre)) {
				prod = p;
			}
		}
		return prod;
		}
	
	 @GET
	 @Path("/fam/{nombre}")
	 @Produces({ MediaType.APPLICATION_JSON})
	 public Familia getFamilia (@PathParam ("nombre") String nombre) throws ServiciosException {
		List<Familia> faml = new ArrayList<Familia>();
		Familia fa = new Familia();
		faml = prodbean.obtenerFamilias();
		for(Familia f : faml) {
			if(f.getFamiNombre().equals(nombre)) {
				fa = f;
				}
		}
		return fa;
		}
	 
	 
	
	 @GET
	    @Path("saludar")
	 @Produces("text/plain")
	    public String saludar(){
	 return "Hola a quien diga hola con producto";
	 }
	 
	 @POST
	 @Path("nvoprod")
	 @Consumes({ MediaType.APPLICATION_JSON})
	 public void addProducto (String prod) {
		System.out.println("entro");
		System.out.println(prod);
		Gson gson = new Gson();
		Producto produc = gson.fromJson(prod, Producto.class);
		 try {
			prodbean.crearProducto(produc);
			
		} catch (ServiciosException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//return Response.ok(prod).build();
	 }
	 
	 @PUT
	 @Path("update")
	 @Consumes({MediaType.APPLICATION_JSON})
	 public Response updateProducto (String dato) {
		 
		 String mensaje;
			Gson gson = new Gson();
			Producto prod= gson.fromJson(dato, Producto.class);
			 try {
				prodbean.actualizarProducto(prod);
				mensaje  = "Actualizado Ok";
			} catch (ServiciosException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				mensaje = "No Actualizado";
			}
			return Response.ok(mensaje).build();
		 
	 }
	 
	 @DELETE
	 @Path("borrar")
	 @Consumes({MediaType.APPLICATION_JSON})
	 
	 public Response borrarProducto (String dato) {
		 System.out.println("entre a borrar");
		 String mensaje;
			Gson gson = new Gson();
			Producto prod= gson.fromJson(dato, Producto.class);
			System.out.println(prod.getProdNombre());
			 try {
				prodbean.eliminarProducto(prod.getProdNombre());
				mensaje  = "Borrado Ok";
			} catch (ServiciosException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				mensaje = "No Borrado";
			}
			return Response.ok(mensaje).build();
		 
	 }
	 
	 
	
/*private static String readAll(Reader rd) throws IOException {
    StringBuilder sb = new StringBuilder();
    int cp;
    while ((cp = rd.read()) != -1) {
      sb.append((char) cp);
      
    }
    return sb.toString();
 }

  public static String readJsonFromtxt(String strprod){
	
    InputStream is = null;
	try {
		is = new URL(strprod).openStream();
	} catch (MalformedURLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
    try {
      BufferedReader rd = new BufferedReader(new InputStreamReader(is, Charset.forName("UTF-8")));
      String jsonText = null;
	try {
		jsonText = readAll(rd);
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}	     
      return jsonText;
    } finally {
      try {
		is.close();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
    }
  }

public String[] leerjson(String strprod){
	Gson gson = new Gson();
	String[] produc = gson.fromJson(strprod, String[].class);
return produc;
}
*/
}
