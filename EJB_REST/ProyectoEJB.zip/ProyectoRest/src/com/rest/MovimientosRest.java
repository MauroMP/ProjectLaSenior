package com.rest;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.ejb.EJB;
import javax.enterprise.context.RequestScoped;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.PATCH;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.google.gson.Gson;

import Exception.ServiciosException;
import Servicio.AlmacenamientoBeanRemote;
import Servicio.MovimientoBeanRemote;
import dominio.Almacenamiento;
import dominio.Movimiento;
import dominio.Producto;

@RequestScoped
@Path("mov")
@Produces({ "application/xml", "application/json" })
@Consumes({ "application/xml", "application/json" })
public class MovimientosRest {
	
	@EJB
	private MovimientoBeanRemote movbean;
	@EJB
	private AlmacenamientoBeanRemote almabean;
	
	 @GET
	    @Path("saludar")
	 @Produces("text/plain")
	    public String saludar(){
	 return "Hola a quien diga hola con movimiento";
	    }
	 
	
	@GET
	@Path("/{id}")
	@Produces({ MediaType.APPLICATION_JSON})
	@Consumes({ MediaType.APPLICATION_JSON})
	public Movimiento getMovimiento (@PathParam("id") Long id) {
		Movimiento mov = new Movimiento();
	    
		try {
			mov = movbean.obtenerMovimiento(id);
		} catch (ServiciosException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	return mov;
	}
	
	 @GET
	 @Path("movs")
	 @Produces({ MediaType.APPLICATION_JSON})
		public List<Movimiento> getMovimientos () {
			List<Movimiento> listmov = new ArrayList<>();
		
			try {
				listmov = movbean.obtenerTodos();
			} catch (ServiciosException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		return listmov;
		}
     
	 @GET
	 @Path("movs/{prodNom}")
	 @Produces({ MediaType.APPLICATION_JSON})
		public List<String> getMovimientosP (@PathParam("prodNom") String prod) {
		 	
			List<String> listmovi = new ArrayList<>();
			List<Movimiento> listmov = new ArrayList<>();
			String idm = "";
		
			try {
				listmov = movbean.obtenerMovimientosP(prod);
				for(Movimiento m : listmov) {
                      idm = m.getMovId().toString();
                      listmovi.add(idm);
                      
				}
				
			} catch (ServiciosException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		return listmovi;
		}

	 
	 @GET
		@Path("obtnom")
		@Produces({ MediaType.APPLICATION_JSON})
	 public List<String> getObtNom () throws ServiciosException {
			List<Almacenamiento> listalma = new ArrayList<>();
			List<String> listalman = new ArrayList<>();
		listalma = almabean.obtenerTodos();
		for(Almacenamiento i:listalma) {
			String n = i.getAlmaNombre();
			listalman.add(n);
		}
		return listalman;
	 }
	 
	 @POST
	 @Path("nvomov")
	 @Consumes({ MediaType.APPLICATION_JSON})
	 public Response addMovimiento (String dato) {
		//System.out.println("entro");
		String mensaje;
		Gson gson = new Gson();
		Movimiento mov = gson.fromJson(dato, Movimiento.class);
		 try {
			movbean.crearMovimiento(mov);
			mensaje =  "Creado Ok";
		} catch (ServiciosException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			mensaje =  "No Creado";
		}
		return Response.ok(mensaje).build();
	 }	 
	 
	 
	 @PUT
	 @Path("update")
	 @Consumes({MediaType.APPLICATION_JSON})
	 public Response updateMovimiento (String dato) {
		 
		 String mensaje;
			Gson gson = new Gson();
			Movimiento mov = gson.fromJson(dato, Movimiento.class);
			 try {
				movbean.modificarMovimiento(mov);
				mensaje  = "Actualizado Ok";
			} catch (ServiciosException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				mensaje = "No Actualizado";
			}
			return Response.ok(mensaje).build();
		 
	 }
	 
	 @DELETE
	 @Path("borrar")
	 @Produces({ MediaType.APPLICATION_JSON})
	 @Consumes({MediaType.APPLICATION_JSON})
	 public Response borrarMovimiento (String dato) {
		 
		 String mensaje;
			Gson gson = new Gson();
			Movimiento mov = gson.fromJson(dato, Movimiento.class);
			System.out.println(mov.getMovId());
			try {
				movbean.borrarMovimiento(mov.getMovId());
				mensaje  = "Borrado Ok";
			} catch (ServiciosException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				mensaje = "No Borrado";
			}
			return Response.ok(mensaje).build();
		 
	 }
	 
	 
	 /*	 @GET
	 @Path("movsp/{producto}")
	 @Produces({ MediaType.APPLICATION_JSON})
	 public List<Movimiento> getMovimientosP (@PathParam ("producto") String producto) {
			List<Movimiento> listmov = new ArrayList<>();
		
			try {
				listmov = movbean.obtenerMovimientosP(producto);
			} catch (ServiciosException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		return listmov;
		}
	 
	 @GET
	 @Path("movsa/{almacen}")
	 @Produces({ MediaType.APPLICATION_JSON})
	 public List<Movimiento> getMovimientosA (@PathParam ("almacen") String almacen) {
			List<Movimiento> listmov = new ArrayList<>();
		
			try {
				listmov = movbean.obtenerMovimientosA(almacen);
			} catch (ServiciosException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		return listmov;
		}
	 @GET
	 @Path("movsd/{descripcion}")
	 @Produces({ MediaType.APPLICATION_JSON})
	 public List<Movimiento> getMovimientosD (@PathParam ("descripcion") String desc) {
			List<Movimiento> listmov = new ArrayList<>();
		System.out.println(desc);
			try {
				listmov = movbean.obtenerMovimientosD(desc);
			} catch (ServiciosException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		return listmov;
		}
	  
	 @GET
	 @Path("movsf/{fecha}")
	 @Produces({ MediaType.APPLICATION_JSON})
	 public List<Movimiento> getMovimientosF (@PathParam ("fecha") Date fecha) {
			List<Movimiento> listmov = new ArrayList<>();
		
			try {
				listmov = movbean.obtenerMovimientosF(fecha);
			} catch (ServiciosException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		return listmov;
		}
	*/ 
	
}
